<?php include "includes/header.php"?>

<body>
	<div id="page" align="center">
		<div id="content" style="width:800px">
			<?php include "includes/logo.php" ?>
			<?php include "includes/headerDiv.php" ?>
			<?php include "includes/menu.php"?>
		<div id="contenttext">
			
			<div class="bodytext" style="padding:12px;" align="justify">
				
				<center><h2 style="padding-top:20px; color: chartreuse;">Welcome to choose our recipes !</h2></center>
				
				<?php include_once "classes/Message.php"?>
				<?php include_once "classes/Carousel.php"?>
				<?php include_once "classes/RecipesDB.php"?>
				<?php include_once "classes/Category.php"?>
				<?php include_once "classes/Rating.php"?>
				<?php include_once "classes/Favorite.php"?>
				<?php include_once "classes/MemberDB.php"?>
				<?php include_once "classes/Sorting.php"?>
				
				<?php
					if(isset($_POST["Submit"])){
						
						$Email = $_POST["Email"];
						$Username = $_POST["Username"];
						$Password = $_POST["Password"]; 
						$Confirmed_Password = $_POST["Confirmed_Password"];
						
						if(Members::Email_Exists($Email)){
							Message::ShowMessage("This email already exists ! Try again...", Message::$Full_Size, Message::$Error);
						}
						
						if(Members::Username_Exists($Username )){
							Message::ShowMessage("This username already exists ! Try again...", Message::$Full_Size, Message::$Error);
						}
						
						if($Password != $Confirmed_Password){
							Message::ShowMessage("The password and its confirmation are not the same ! Try again...", Message::$Full_Size, Message::$Error);
						}
						if(  empty($Email) || empty($Username) || empty($Password) || empty($Confirmed_Password))
						{
							Message::ShowMessage("Enter a value for each required field !", Message::$Full_Size, Message::$Error);
						}
						else{
							if(!Members::Email_Exists($Email) && !Members::Username_Exists($Username) && $Password == $Confirmed_Password )
							{
								$userObj = new Members($Username, $Email, $Password);
								$userObj->InsertNew();
								Message::ShowMessage("Your account is successfully created !", Message::$Full_Size, Message::$Success);
							}
						}						
					}
				?>

<!---------------------------------------------------------------------------------------------------->
<div class="container" style="width: 400px;text-align: center;">
	<div class="d-flex justify-content-center h-100">
		<div class="card" style="width: 350px;">
			<!-- Card Header -->
			<div class="card-header">
				<div class="row justify-content-md-center"><img src="images/logo1.JPG" height="100px" width="100px;"></div>
			</div>

			<!-- Card Body -->
			<div class="card-body">
				<form action = "#" method = "POST">

					<!-- Email -->
					<div class="input-group form-group">
						<div class="input-group-prepend"><span class="input-group-text">
						<i class="fa fa-envelope"></i></div><input type="email" name="Email" placeholder="Email" class="form-control" required />	
					    <font color="red"><b>*</b></font></span>
					</div>
			
					<!-- Username -->
					<div class="input-group form-group">
						<div class="input-group-prepend"><span class="input-group-text">
						<i class="fa fa-certificate"></i></div><input type="text" name="Username" placeholder="Username" class="form-control" required />	
					    <font color="red"><b>*</b></font></span>
					</div>
			
					<!-- Password -->
					<div class="input-group form-group">
						<div class="input-group-prepend"><span class="input-group-text">
						<i class="fa fa-key"></i></div><input type="Password" name="Password" placeholder="Password" class="form-control" required />	
					    <font color="red"><b>*</b></font></span>
					</div>
					
					<!-- Confirm Password -->
					<div class="input-group form-group">
						<div class="input-group-prepend"><span class="input-group-text">
						<i class="fa fa-key"></i></div><input type="password" name="Confirmed_Password" placeholder="Confirmed Password" class="form-control" required />	
					    <font color="red"><b>*</b></font></span>
					</div>
	
					<!-- Submit -->
					<div class="form-group">
						<input type="submit" name="Submit" value="Register" class="btn btn-danger float-right ">
					</div>
				</form>
			</div>
						
			<div class="card-footer">
				<div class="d-flex justify-content-center links">
					already have an account?<a href="Login.php">Login Now!</a>
				</div>
			</div>
		</div>
	</div>						
				</div>
			</div>
		</div>			
	
	<div align="center">
		<?php include "includes/footer_menu.php"?>
	</div>
	<?php include "includes/footer_links.php"?>