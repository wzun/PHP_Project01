<div id="menu">
<div align="right" class="smallwhitetext" style="padding:9px;">
<a href="HomePage.php"><i class="fa fa-home"></i> Home</a> | 
	<a href="Recipes.php"><i class="fa fa-star"></i> Recipes</a>| 
	<a href="Register.php"><i class="fa fa-user"> </i> Register</a> | 
	<a href="Login.php"><i class="fa fa-sign-in" aria-hidden="true"></i> Login</a>
   
</div>
</div>
