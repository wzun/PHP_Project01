<?php ob_start(); ?>


<?php include "includes/header.php"?>

<body>
	<div id="page" align="center" style="background-color:burlywood; important!">
		<div id="content" style="width:800px">
			<?php include "includes/logo.php" ?>
			<?php include "includes/headerDiv.php" ?>
			<?php include "includes/menu.php"?>
		<div id="contenttext">
			
			<div class="bodytext" style="padding:12px;" align="justify">
				
				<center><h2 style="padding-top:20px; color: cornflowerblue;">Welcome to choose our recipes !</h2></center>
				
				<?php include_once "classes/Message.php"?>
				<?php include_once "classes/Carousel.php"?>
				<?php include_once "classes/RecipesDB.php"?>
				<?php include_once "classes/Category.php"?>
				<?php include_once "classes/Rating.php"?>
				<?php include_once "classes/Favorite.php"?>
				<?php include_once "classes/MemberDB.php"?>
				<?php include_once "classes/Sorting.php"?>
				
				<?php
	
					if(!isset($_SESSION)){
						session_start();
					}

				    if(isset($_POST["Submit1"])){
												
						$Username = $_POST["Username"];
						$Password = $_POST["Password"]; 
						
						if( Members::Login_By_Username($Username, $Password)){
							$_SESSION['Username'] = $Username;
							$_SESSION['Mem_ID']  = Members::Get_Mem_ID($Username);
							
							//SAVE LOGIN IN COOKIE
							if (isset($_POST["Remember_Me"]) ){
								$expiration = time() + (60*60*24*365);//365 days
								setcookie('Cookie_Username', $_POST["Username"], $expiration);
								setcookie('Cookie_Password', $_POST["Password"], $expiration);
							}
							Message::ShowMessage("Your are successfully logged-in !", Message::$Full_Size, Message::$Success);
							Message::ShowMessage("Proccessing to welcome page ......");							
							header('Location: Member/Member.php');
							
							
						}else{
							Message::ShowMessage("Your Username and Password do not match with our records !", Message::$Full_Size, Message::$Error);
						}						
					}

					 if(isset($_POST["Submit2"])){
												
						$Email = $_POST["Email"];
						$Password = $_POST["Password"]; 
						
						if( Members::Login_By_Email($Email, $Password)){
							
							$_SESSION['Email'] = $Email;
							$_SESSION['Mem_ID']  = Members::Get_Mem_ID1($Email);
							
							//SAVE LOGIN IN COOKIE
							if (isset($_POST["Remember_Me"]) ){
								$expiration = time() + (60*60*24*365);//365 days
								setcookie('Cookie_Email', $_POST["Email"], $expiration);
								setcookie('Cookie_Password', $_POST["Password"], $expiration);
							}
							
							Message::ShowMessage("Your are successfully logged-in !", Message::$Full_Size, Message::$Success);
							Message::ShowMessage("Proccessing to welcome page ......");							
							header('Location: Member/Member.php');
							
							
						}else{
							Message::ShowMessage("Your Email and Password do not match with our records !", Message::$Full_Size, Message::$Error);
						}						
					}

					$Cookie_Username = '';
					$Cookie_Email = '';
					$Cookie_Password = '';
					if(isset($_COOKIE["Cookie_Username"]) && isset($_COOKIE["Cookie_Email"]) && $_COOKIE["Cookie_Password"]){
						$Cookie_Username = $_COOKIE["Cookie_Username"];
						$Cookie_Email = $_COOKIE["Cookie_Email"];
						$Cookie_Password = $_COOKIE["Cookie_Password"];
					}
				?>
<!---------------------------------------------------------------------------------->							
<div class="container" style="width: 450px;text-align: center;">
	<div class="d-flex justify-content-center h-100">
		<div class="card" style="width: 350px;">
			<!-- Card Header -->
			<div class="card-header">
				<div class="row justify-content-md-center"><img src="images/user-password.png" height="100px" width="100px;"></div>
			</div>
			<!-- Card Body -->
			<div class="card-body">
				<form action = "#" method = "POST">
					
				<!-- Username -->
					<div class="input-group form-group">
						<div class="input-group-prepend"><span class="input-group-text">
						<i class="fa fa-user"></i></span></div>
						
						<input type="text" name="Username" value="<?php echo $Cookie_Username?>" placeholder="Username" class="form-control" require/>	
					    <font color="red"><b>*</b></font>
					</div>
					
				<!-- Password -->
					<div class="input-group form-group">
						<div class="input-group-prepend"><span class="input-group-text"><i class="fa fa-key"></i></span></div>
						
						<input type="password" name="Password" value="<?php echo $Cookie_Password?>" placeholder="Password"  class="form-control" require/>
						<font color="red"><b>*</b></font>
					</div>
					
				<!-- Remember Me -->
					<div class="row align-items-center remember"><input type="checkbox" name="Remember_Me" >Remember Me</div>
					
				<!-- Submit -->
					<div class="form-group">
						<input type="submit" name="Submit1" value="Login" class="btn btn-danger float-right ">
					</div>
					<div>
						<br><br><br>
						<br><?php echo('<h5>---------------- OR ----------------</h5>') ?><br>
					</div>
				</form>
				
				<form action = "#" method = "POST">
				<!-- Email -->
					<div class="input-group form-group">
						<div class="input-group-prepend"><span class="input-group-text">
						<i class="fa fa-envelope"></i></span></div>
						
						<input type="email" name="Email" value="<?php echo $Cookie_Email?>" placeholder="Email" class="form-control" />	
					    <font color="red"><b>*</b></font>
					</div>
					
				<!-- Password -->
					<div class="input-group form-group">
						<div class="input-group-prepend"><span class="input-group-text"><i class="fa fa-key"></i></span></div>
						
						<input type="password" name="Password" value="<?php echo $Cookie_Password?>" placeholder="Password"  class="form-control" />
						<font color="red"><b>*</b></font>
					</div>
					
				<!-- Remember Me -->
					<div class="row align-items-center remember"><input type="checkbox" name="Remember_Me" >Remember Me</div>
				
				<!-- Submit -->
					<div class="form-group">
						<input type="submit" name="Submit2" value="Login" class="btn btn-danger float-right ">
					</div>
				</form>
			
			</div>
			
			<!-- Card Footer -->
			<div class="card-footer">
				<div class="d-flex justify-content-center links">Don't have an account?&rarr; <a href="Register.php"> --> Sign Up </a></div>
				<div class="d-flex justify-content-center"><a href="ResetPassword.php">Forgot your password?</a></div>
			</div>
		</div><!-- End Card -->
	</div>
	</div><!-- End Container -->
				
	</div><!-- End Bodytext -->
		
	</div>
	<div align="center">
		<?php include "includes/footer_menu.php"?>
	</div>
	<?php include "includes/footer_links.php"?>