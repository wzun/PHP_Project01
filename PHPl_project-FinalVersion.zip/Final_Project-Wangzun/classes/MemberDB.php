
<?php  

	require_once "Database.php";

class Members{
		
	private $Mem_ID;
	private $Username;
	private $Email;
	private $Password;
	private $Salt;

//<!-------------------constructor-------------------->
	
	function Members($Username, $Email, $Password, $Mem_ID = NULL)
	{
		
		$this->Username  = $Username;		
		$this->Email = $Email;
		
		$this->Salt = $this->Create_Salt();
		$this->Password = crypt($Password, $this->Salt);
		
		$this->Mem_ID = $Mem_ID;

	}
	
//-------------------create salt and crypt password--------------------
	
	public function Create_Salt(){
		$algorithms = array("2a", "2x", "2y");
		$index = rand(0,2);
		$string = substr (MD5($this->Username), 0, 22);
		return "$".$algorithms[$index]."$"."05"."$".$string."$";
	}

	
	
//------------------------------register-----------------------------------------------		
	//---------------- register step 1 : judge Email or Username exist -------------
	
	public static function Username_Exists($Username){
				
		try{			
			$query = "SELECT * FROM members WHERE Username = '$Username'";
		
			$database = Database::Get_Instance();
		    $connection = $database->Get_Connection();
			$statement  = $connection->prepare($query);
			$statement->execute();
			
			$result = $statement->fetch(PDO::FETCH_ASSOC);		
			
			if(!empty($result['Mem_ID'])){
				return true;
			}
	
			return false;
			
		}catch(PDOException $e){
			echo "SELECT Query Failed : ".$e->getMessage();
		}	
			}
	//------------------------------------------------------------------
	
	public static function Email_Exists($Email){
		
		try{			
			$query = "SELECT * FROM members WHERE Email = '$Email'";
		
			$database = Database::Get_Instance();
		    $connection = $database->Get_Connection();
			$statement  = $connection->prepare($query);
			$statement->execute();
			
			$result = $statement->fetch(PDO::FETCH_ASSOC);		
			
			if(!empty($result['Mem_ID'])){
				return true;
			}
	
			return false;
			
		}catch(PDOException $e){
			echo "SELECT Query Failed : ".$e->getMessage();
		}	
	}
	
	//-----------------register step2 :insert into DB----------------------------
	
	public function InsertNew(){
		
		try{			
			$query = "INSERT INTO members (Mem_ID, Username, Email, Password, salt)";
			$query .= " VALUES(?,?,?,?,?)";
			
		    $database = Database::Get_Instance();
			$connection = $database->Get_Connection();
			$statement  = $connection->prepare($query);
			
			$statement->bindParam(1, $this->Mem_ID);
			$statement->bindParam(2, $this->Username);
			$statement->bindParam(3, $this->Email);
			$statement->bindParam(4, $this->Password);
			$statement->bindParam(5, $this->Salt);
			
			$statement->execute();
			
		}catch(PDOException $e){
			echo "INSERT Query Failed : ".$e->getMessage();
		}	
	}
	
	
//----------------------------------------login------------------------------------------------
	
	public static function Login_By_Username($Username , $Password){
		try{
		
			$query = "SELECT * FROM members WHERE Username = '$Username'";
		
			$database = Database::Get_Instance();
		    $connection = $database->Get_Connection();
			$statement  = $connection->prepare($query);
			$statement->execute();
			
			$result = $statement->fetch(PDO::FETCH_ASSOC);
			
			$salt = $result['Salt'];
			$encrypted_password = crypt($Password, $salt);
			
			if($encrypted_password == $result['Password']){
				return true;
			}
	
			return false;
			
		}catch(PDOException $e){
			echo "SELECT Query Failed : ".$e->getMessage();
		}	
	}

	//--------------------------------------------------------------
	
	public static function Login_By_Email($Email , $Password){
		try{
		
			$query = "SELECT * FROM members WHERE Email = '$Email'";
		
			$database = Database::Get_Instance();
		    $connection = $database->Get_Connection();
			$statement  = $connection->prepare($query);
			$statement->execute();
			
			$result = $statement->fetch(PDO::FETCH_ASSOC);
			
			$salt = $result['Salt'];
			$encrypted_password = crypt($Password, $salt);
			
			if($encrypted_password == $result['Password']){
				return true;
			}
	
			return false;
			
		}catch(PDOException $e){
			echo "SELECT Query Failed : ".$e->getMessage();
		}	
	}
	
//----------------------------------reset password-------------------------------------			
	//---------------reset password step1 : judge exists------------------------------
		
	public static function Username_Email_Exists($Username, $Email){
		try{
			$query = "SELECT * FROM members WHERE Username = '$Username' AND Email = '$Email'";
		
			$database = Database::Get_Instance();
		    $connection = $database->Get_Connection();
			$statement  = $connection->prepare($query);
			$statement->execute();
			
			$result = $statement->fetch(PDO::FETCH_ASSOC);		
			
			if(!empty($result['Mem_ID'])){
				return true;
			}
	
			return false;
			
		}catch(PDOException $e){
			echo "INSERT Query Failed : ".$e->getMessage();
		}	
	}
	
	//----------------reset password step2 : update DB --------------------------
	
	public static function Update_Password($Username, $Password){
		
		try{
			$salt = self::Get_Salt($Username);
			$encrypted_password = crypt($Password, $salt);
			
			$query = "Update members SET Password = '$encrypted_password' ";
			$query .= " WHERE Username = '$Username' ";
			
			$database = Database::Get_Instance();
			$connection = $database->Get_Connection();
			$connection->exec($query);
			
		}catch(PDOException $e){
			echo "Update Query Failed : ".$e->getMessage();
		}
	}
	
	//--------------------get salt for reset and crypt password --------------------------
	
	public static function Get_Salt($Username){
		try{
			
			$query = "SELECT * FROM members WHERE Username = '$Username' ";
			
			$database = Database::Get_Instance();
			$connection = $database->Get_Connection();
			$statement = $connection->prepare($query);
			$statement->execute();
			$result = $statement->fetch(PDO::FETCH_ASSOC);
			return $result['Salt'];
			
		}catch(PDOException $e){
			echo "SELECT Query Failed : ".$e->getMessage();
		}
	}
	

	
	//--------------------get member ID for login by Username--------------------------
	
	public static function Get_Mem_ID($Username){
		
		try{			
			$query = "SELECT * FROM members WHERE Username = '$Username' ";
			
			$database = Database::Get_Instance();
			$connection = $database->Get_Connection();
			$statement = $connection->prepare($query);
			$statement->execute();
			
			$result = $statement->fetch(PDO::FETCH_ASSOC);
			return $result['Mem_ID'];
			
		}catch(PDOException $e){
			echo "SELECT Query Failed : ".$e->getMessage();
		}
	}
	
	//--------------------get member ID for login by Email--------------------------
	public static function Get_Mem_ID1($Email){
		
		try{			
			$query = "SELECT * FROM members WHERE Email = '$Email' ";
			
			$database = Database::Get_Instance();
			$connection = $database->Get_Connection();
			$statement = $connection->prepare($query);
			$statement->execute();
			
			$result = $statement->fetch(PDO::FETCH_ASSOC);
			return $result['Mem_ID'];
			
		}catch(PDOException $e){
			echo "SELECT Query Failed : ".$e->getMessage();
		}
	}
	
}
?>
	