<?php 
require_once "Database.php";

class Category{
	
//takes the Category_ID as input and provide the Category Name as output
	
	public static function Get_Category_Name($id){
		
		try{
			$query = "SELECT Cat_Name FROM categories WHERE Cat_ID = $id ";
			
			$database = Database::Get_Instance();
			$connection = $database->Get_Connection();
			$statement = $connection->prepare($query);
			$statement->execute();
			$result = $statement->fetch(PDO::FETCH_ASSOC);
			return $result["Cat_Name"];
			
		}catch(PDOException $e ){
			echo "Query Failed ". $e->getMessage();
		}
	}
	
	//takes the Mealtype_ID as input and provide the mealtype Name as output
	
	public static function Get_MealType_Name($id){
		
		try{
			$query = "SELECT MealType_Name FROM meal_type WHERE MealType_ID = $id ";
			
			$database = Database::Get_Instance();
			$connection = $database->Get_Connection();
			$statement = $connection->prepare($query);
			$statement->execute();
			$result = $statement->fetch(PDO::FETCH_ASSOC);
			return $result["MealType_Name"];
			
		}catch(PDOException $e ){
			echo "Query Failed ". $e->getMessage();
		}
	}
}
?>