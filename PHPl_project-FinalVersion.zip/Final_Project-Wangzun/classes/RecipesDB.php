<?php 

require_once "Database.php";
require_once "Rating.php";
require_once "Favorite.php";

class Recipes{
		
	private $Recipe_ID;
	private $Name;
	private $Preparation_Time;
	private $Cooking_Time;
	private $Serving_Person;
	private $MealType_ID;
	private $MealType_Name;
	private $Preparation;
	private $Image;
	private $Rating;
	private $Recipe_Date;
	private $Ing_ID;
	
	//<!------------------constructor------------------------>
	
	function Recipe($Recipe_ID, $Name, $Preparation_Time, $Cooking_Time, $Serving_Person,
	                     $MealType_ID, $MealType_Name, $Preparation, $Image, $Rating, $Recipe_Date, $Ing_ID ){
		
		$this->Recipe_ID = $Recipe_ID;
		$this->Name = $Name;
		$this->Preparation_Time = $Preparation_Time;
		$this->Cooking_Time = $Cooking_Time;
		$this->Serving_Person = $Serving_Person;
		$this->MealType_ID = $MealType_ID;
		$this->MealType_Name = $MealType_Name;
		$this->Preparation = $Preparation;
		$this->Image = $Image;
		$this->Rating = $Rating;
		$this->Recipe_Date = $Recipe_Date;
		$this->Ing_ID = $Ing_ID;
	}		
			
//<!-------------------------------visitor display and search recipes----------------------------------->
	//<!-----------------read all recipes array from DB and display------------------------>
	
	public static function ReadRecipes(){
		
		try{
		
			$query = "SELECT * FROM recipes";
			$database = Database::Get_Instance();
		    $connection = $database->Get_Connection();
			$statement  = $connection->prepare($query);
			$statement->execute();
			
			$result = $statement->fetchAll(PDO::FETCH_ASSOC);
			
			return $result;
			
		}catch(PDOException $e){
			echo "Query Failed : ".$e->getMessage();
		}			
	}
	
	//<!-------------------  search recipes by Cat_ID ------------------->
	
	public static function Search_By_CAT_ID($Cat_ID){
		
		try{
			$query = "SELECT * FROM recipes R inner join recipes_categories C "; 
			$query .= " on R.Recipe_ID = C.Recipe_ID  WHERE Cat_ID = $Cat_ID";
			$database = Database::Get_Instance();
			$connection = $database->Get_Connection();
			$statement = $connection->prepare($query);
			$statement->execute();
			$result = $statement->fetchall(PDO::FETCH_ASSOC);
			return $result;
			
		}catch(PDOException $e){ 
			echo "Query failed ".$e->getMessage();
		}
	}
	
	//<!-------------------  search recipes by MealType ------------------->
	public static function Search_By_MealType($MealType_ID){
		
		try{
			$query = "SELECT * FROM recipes WHERE MealType_ID = $MealType_ID";
			$database = Database::Get_Instance();
			$connection = $database->Get_Connection();
			$statement = $connection->prepare($query);
			$statement->execute();
			$result = $statement->fetchall(PDO::FETCH_ASSOC);
			return $result;
			
		}catch(PDOException $e){ 
			echo "Query failed ".$e->getMessage();
		}
	}
	
	
	//-------------------------------------------------------------------
	
	public static function Display_Visitor($array){
	
		foreach($array as $row){
			echo '<div class="card mb-2 mt-2 w-100"><div class="card-body">';
			echo '<div class="row no-gutters">';
				echo '<div class="col-md-6">';
				echo "<a href='Recipes_Details.php?Recipe_ID=".$row['Recipe_ID']."'>";

				echo '<img src= "images/recipes/'.$row['Image']." \" height = '250' width = '220px'>";
			echo "</a>";
			echo "<br><br><br>";
			//----------display avg rating----------
				$rating_avg = Rating::Calculate_Rating($row['Recipe_ID']);
				Rating::Display_Stars($rating_avg);
			
			echo "<br><br><br>";
			echo "<h6><a href='Recipes_Details.php?Recipe_ID=".$row['Recipe_ID']."'>View Details >>> </a></h6>";
			echo "</div >";
			
			
			//---------------------------------------
			echo '<div class="col-md-6">';
				echo "<font color = green>";
				echo "<h5>". $row['Name']."</h5><br>";
		
				echo "<br><font color = blue>";
				echo "<h6>Preparation Time :". $row['Preparation_Time']." <br>Cooking Time : ".$row['Cooking_Time']." <br>Serving Person : " .$row['Serving_Person']."</h6>";
				
				echo "<font color = red>";
				echo "<h6>Meal Type : ".$row['MealType_Name']." <br></h6>";
				echo "</font>";
			
				echo "<font color = black>";
				echo "<h6>Preparation : ".$row['Preparation']."</h6>";
				echo "</font> <br>";
			
				echo "<font color = yellow>";
				echo "<h6> Recipe_Date : ". $row['Recipe_Date']."</h6>";
				echo "</font>";
			
				echo '</div>';	
				echo '</div>';
		    echo '</div></div>';
		}
	}

	
//<!------------------------------ show details page --------------------------------------->		
	//<!------------------- show details by search recipes ID ------------------->
	
	public static function Search_By_ID($Recipe_ID){
		
		try{
			$query = "SELECT * FROM recipes WHERE Recipe_ID = $Recipe_ID";
			$database = Database::Get_Instance();
			$connection = $database->Get_Connection();
			$statement = $connection->prepare($query);
			$statement->execute();
			$result = $statement->fetch(PDO::FETCH_ASSOC);
			return $result;
			
		}catch(PDOException $e){ 
			echo "Query failed ".$e->getMessage();
		}
	}
	
	//<!----------------------display choosed recipe--------------------------->
	public static function Display_Detail($row, $Mem_ID = NULL){
		
			echo '<div class="card mb-2 mt-2 w-100"><div class="card-body">';
			echo '<div class="row no-gutters">';
				echo '<div class="col-md-6">';
				echo "<a href='Recipes_Details.php?Recipe_ID=".$row['Recipe_ID']."'>";

				echo '<img src= "images/recipes/'.$row['Image']." \" height = '250' width = '220px'>";
			echo "</a>";
			echo "<br><br><br>";
			
			echo '</br>';
			echo "<a href='Recipes.php'>";
			echo "<button class='btn btn-secondary'><span class='fa fa-caret-left'></span></button>";
			echo "</a>";
			
			echo "</div >";
						
			//---------------------------------------
			echo '<div class="col-md-6">';
				echo "<font color = green>";
				echo "<h5>". $row['Name']."</h5><br>";
		
				echo "<br><font color = blue>";
				echo "<h6>Preparation Time :". $row['Preparation_Time']." <br>Cooking Time : ".$row['Cooking_Time']." <br>Serving Person : " .$row['Serving_Person']."</h6>";
				
				echo "<font color = red>";
				echo "<h6>Meal Type : ".$row['MealType_Name']." <br></h6>";
				echo "</font>";
			
				echo "<font color = black>";
				echo "<h6>Preparation : ".$row['Preparation']."</h6>";
				echo "</font> <br>";
			
				echo "<font color = yellow>";
				echo "<h6> Recipe_Date : ". $row['Recipe_Date']."</h6>";
				echo "</font>";
			
				echo '</div>';	
				echo '</div>';
		    echo '</div></div>';
		
		echo '</div>';
		echo '<div class="card-footer">';
		echo '<div class="row no-gutters">';
		//-------------------------------------------------------------------
		echo '<div class="col-md-4">';
		echo "<font color = #CC0000><h6> Average Rating: </font></h6><br>";
		
			Rating::Display_Stars(Rating::Calculate_Rating($row['Recipe_ID']));
		echo '</div>';
		echo '<div class="col-md-4">';
		if(!empty($Mem_ID)){
			$mem_rating = Rating::Calculate_Rating($row['Recipe_ID'], $Mem_ID);
			Rating::Display_Form(Round($mem_rating, 1));
		}
		echo '</div>';
		echo '<div class="col-md-4">';
		if(!empty($Mem_ID)){
			$isFavorite = Favorite::IsFavorite($Mem_ID, $row['Recipe_ID']);
			Favorite::Display_Add_Form($isFavorite);
		}
				
		echo '</div>';
		echo '</div>';	
		echo '</div>';			
		}
	
	//<!-------------------search one recipes from DB by recipes Name-------------------->
	
	public static function Search_By_Name($Name){
		
		try{
			$query = "SELECT * FROM recipes WHERE Name = $Name";
			$database = Database::Get_Instance();
			$connection = $database->Get_Connection();
			$statement = $connection->prepare($query);
			$statement->execute();
			$result = $statement->fetch(PDO::FETCH_ASSOC);
			return $result;
			
		}catch(PDOException $e){ 
			echo "Query failed ".$e->getMessage();
		}
	}
	
	
	//<!---------------------------------------favorite page------------------------------------->
	
	public static function Get_Favorite_Recipes($Mem_ID){
        try{
			$query = "SELECT * FROM recipes R INNER JOIN favorites F ON R.Recipe_ID = F.Recipe_ID AND F.Mem_ID = $Mem_ID ";
			
			$database = Database::Get_Instance();
			$connection = $database->Get_Connection();
			$statement = $connection->prepare($query);
			$statement->execute();
			
			return $statement->fetchAll(PDO::FETCH_ASSOC);
        
		}catch(PDOException $e){
			echo "Query Failed ".$e->getMessage();
		}
    }
	
	
	public static function Display_Favorite($array, $isFavoriteList = FALSE){
			
		foreach($array as $row){
			echo '<div class="card mb-2 mt-2 w-100"><div class="card-body">';
			echo '<div class="row no-gutters">';
			
			//---------------------------------------
			echo '<div class="col-md-6">';			
			echo "<a href='Recipes_Details.php?Recipe_ID=".$row['Recipe_ID']."'>";
				echo '<img src= "images/recipes/'.$row['Image']." \" height = '250' width = '220px'>";
			echo "</a>";
			echo "<br><br><br>";

				$rating_avg = Rating::Calculate_Rating($row['Recipe_ID']);
				Rating::Display_Stars($rating_avg);
			
			echo "<br><br><br>";
			echo "<h6><a href='Recipes_Details.php?Recipe_ID=".$row['Recipe_ID']."'>View Details >>> </a></h6>";			
			
			echo "<br><br><br>";
				if($isFavoriteList){
					Favorite::Display_Delete_Form($row['Recipe_ID']);
				}
			echo "</div >";
			
		//---------------------------------------
			echo '<div class="col-md-6">';
				echo "<font color = green>";
				echo "<h5>". $row['Name']."</h5><br>";
		
				echo "<br><font color = blue>";
				echo "<h6>Preparation Time :". $row['Preparation_Time']." <br>Cooking Time : ".$row['Cooking_Time']." <br>Serving Person : " .$row['Serving_Person']."</h6>";
				
				echo "<font color = red>";
				echo "<h6>Meal Type : ".$row['MealType_Name']." <br></h6>";
				echo "</font>";
			
				echo "<font color = black>";
				echo "<h6>Preparation : ".$row['Preparation']."</h6>";
				echo "</font> <br>";
			
				echo "<font color = yellow>";
				echo "<h6> Recipe_Date : ". $row['Recipe_Date']."</h6>";
				echo "</font>";
			
				echo '</div>';	
				echo '</div>';
		    echo '</div></div>';
		}
	}
}
?>