<?php

include_once "Database.php";

class Favorite {
    
	//add favorite
    public static function Add_Favorite($Mem_ID, $Recipe_ID){
       
		try{
			$query  = "INSERT INTO favorites(Mem_ID, Recipe_ID)";
			$query .= " VALUES(?, ?)";
			
			$database = Database::Get_Instance();
			$connection = $database->Get_Connection();
			$stmt = $connection->prepare($query);
			$stmt->bindParam(1,$Mem_ID);
			$stmt->bindParam(2,$Recipe_ID);
          
			$stmt->execute();
			
		}catch(PDOException $e){
			echo "Query Failed ".  $e->getMessage();
		}
    }
    
    //judge if is already favorite   
    public static function IsFavorite($Mem_ID, $Recipe_ID){
		
		try{
			$query = "SELECT Count(*) FROM favorites WHERE Mem_ID = $Mem_ID AND Recipe_ID = $Recipe_ID";
            
			$database = Database::Get_Instance();
			$connection = $database->Get_Connection();
			$stmt = $connection->prepare($query);	
			$stmt->execute();
			$result = $stmt->fetch(PDO::FETCH_ASSOC);
			
			return !empty($result['Count(*)']);
			
		}catch(PDOException $e){
			echo "Query Failed ".$e->getMessage();
		}
	}
    
	//remove favorite
    public static function Delete_Favorite($Mem_ID, $Recipe_ID){
	
		try{
			$query = "Delete FROM favorites WHERE Recipe_ID = $Recipe_ID AND Mem_ID = $Mem_ID";
			
			$database = Database::Get_Instance();
			$connection = $database->Get_Connection();
			$connection->exec($query);
			
		}catch(PDOException $e){
			echo "Delete Query Failed ".$e->getMessage();
		}
	}
       
    //display delete favorite
    public static function Display_Delete_Form($Recipe_ID){
        echo "<form action = '#' method = 'post'>";
        echo "<input type = 'hidden' name= 'Recipe_ID' value =".$Recipe_ID." >";
        echo "<button type ='submit' name = 'Delete' class='btn btn-danger'><span class='fa fa-trash'></span></button>";
        echo "</form>";
	}
	
	//display add favorite
	public static function Display_Add_Form($isFavorite = FALSE){
		echo "<form action = '#' method = 'POST'>";
        echo "<input type = 'hidden' name= 'Favorite' >";
		echo '<div class="pretty p-icon p-toggle p-plain" style="font-size:16px;color:red;">'; 
			echo '<input type="checkbox" name = "Checkbox" ';
			if($isFavorite){ echo "checked"; }
			echo ' onchange="this.form.submit();"  />'; 
			echo '<div class="state p-off">'; 
			echo '<i class="icon fa fa-heart-o" ></i>'; 
			echo '<label>Add Favorite</label>'; 
			echo '</div>'; 
			echo '<div class="state p-on p-danger-o">'; 
			echo '<i class="icon fa fa-heart"></i>'; 
			echo '<label>Remove Favorite</label>'; 
			echo '</div>'; 
		echo '</div>'; 	
        echo "</form>";
	}
    
}
?>