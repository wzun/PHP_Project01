<?php include "includes/header.php"?>

<body>
	<div id="page" align="center">
		<div id="content" style="width:800px">
			<?php include "includes/logo.php" ?>
			<?php include "includes/headerDiv.php" ?>
			<?php include "includes/menu.php"?>
		<div id="contenttext">
			
			<div class="bodytext" style="padding:12px;" align="justify">
				
				<center><h2 style="padding-top:20px;  color:aqua;">Welcome to choose our recipes !</h2></center>
				
				<?php include_once "classes/Message.php"?>
				<?php include_once "classes/Carousel.php"?>
				<?php include_once "classes/RecipesDB.php"?>
				<?php include_once "classes/Category.php"?>
				<?php include_once "classes/Rating.php"?>
				<?php include_once "classes/Favorite.php"?>
				<?php include_once "classes/MemberDB.php"?>
				<?php include_once "classes/Sorting.php"?>
				
				<?php
				if(isset($_POST["Submit"])){
						
						$Email = $_POST["Email"];
						$Username = $_POST["Username"];
						$Password = $_POST["Password"]; 
						$Confirm_Password = $_POST["Confirm_Password"]; 
						
						if($Password == $Confirm_Password){
							if( Members::Username_Email_Exists($Username, $Email) ){
								Members::Update_Password($Username , $Password);
								Message::ShowMessage("Your password is updated successfully !", Message::$Full_Size, Message::$Success);
							}else{
								Message::ShowMessage("Your Username and Email do not match with our records !", Message::$Full_Size, Message::$Error);
							}
						}else{
							Message::ShowMessage("Your Password and Confirmed Password do not match !", Message::$Full_Size, Message::$Error);
						}
						
					}
				?>
	<div class="container">
	<div class="d-flex justify-content-center h-100">
		<div class="card">
			<!-- Card Header -->
			<div class="card-header">
				<div class="row  justify-content-md-center"><img src="images/reset.png" height="100px" width="100px;"></div>
			</div>
			<!-- Card Body -->
			<div class="card-body">
				<form action = "#" method = "POST">
				   <!-- Username -->
					<div class="input-group form-group">
						<div class="input-group-prepend"><span class="input-group-text">
						<i class="fa fa-user"></i></span></div><input type="text" name="Username" placeholder="Username" class="form-control" required />	
					    <font color="red"><b>*</b></font>
					</div>
					<!-- Email -->
					<div class="input-group form-group">
						<div class="input-group-prepend"><span class="input-group-text">
						<i class="fa fa-envelope"></i></span></div><input type="email" name="Email" placeholder="Email" class="form-control" required />	
					    <font color="red"><b>*</b></font>
					</div>
					<!-- Password -->
					<div class="input-group form-group">
						<div class="input-group-prepend"><span class="input-group-text"><i class="fa fa-key"></i></span></div>
						<input type="password" name="Password" placeholder="New Password"  class="form-control" required />
						<font color="red"><b>*</b></font>
					</div>
					<!-- Password Confirmation-->
					<div class="input-group form-group">
						<div class="input-group-prepend"><span class="input-group-text"><i class="fa fa-key"></i></span></div>
						<input type="password" name="Confirm_Password" placeholder="Confirm Password"  class="form-control" required />
						<font color="red"><b>*</b></font>
					</div>
					
					<!-- Submit -->
					<div class="form-group">
						<input type="submit" name="Submit" value="Change" class="btn btn-danger float-right ">
					</div>
				</form>
			</div>
			<!-- Card Footer -->
			<div class="card-footer">
				<div class="d-flex justify-content-center links">Don't have an account?<a href="Register.php"> -->Sign Up</a></div>
			</div>
		</div><!-- End Card -->
	</div>
	</div><!-- End Container -->
				
	</div><!-- End Bodytext -->
		</div>

	<div align="center">
		<?php include "includes/footer_menu.php"?>
	</div>
	<?php include "includes/footer_links.php"?>