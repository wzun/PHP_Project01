<?php include "includes/header.php"?>

<body>
	<div id="page" align="center">
		<div id="content" style="width:800px">
			<?php include "includes/logo.php" ?>
			<?php include "includes/headerDiv.php" ?>
			<?php include "includes/menu.php"?>
		<div id="contenttext">
			
				<?php include_once "../classes/Message.php"?>
				<?php include_once "../classes/Carousel.php"?>
				<?php include_once "../classes/RecipesDB.php"?>
				<?php include_once "../classes/Category.php"?>
				<?php include_once "../classes/Rating.php"?>
				<?php include_once "../classes/Favorite.php"?>
				<?php include_once "../classes/MemberDB.php"?>
				<?php include_once "../classes/Sorting.php"?>
			
			<div class="bodytext" style="padding:12px;" align="justify">
				
				<center><h2 style="padding-top:20px;  color:darkorange;">Welcome to choose our recipes !</h2></center>
				<br><br>

				<?php 
					
					if(isset($_GET['Recipe_ID'])){
						
						$Mem_ID = $_SESSION['Mem_ID'];
						$Recipe_ID = $_GET['Recipe_ID'];
						
						if(isset($_POST["rating"]))	{
							$rating_obj = new Rating($Recipe_ID, $Mem_ID , $_POST["rating"]);
							$rating_obj->Create();
						}
						if(isset($_POST["Favorite"])){
							if(isset($_POST["Checkbox"])){
								Favorite::Add_Favorite($Mem_ID, $Recipe_ID);
							}else{
								Favorite::Delete_Favorite($Mem_ID, $Recipe_ID);
							}
						}
						$Recipe = Recipes::Search_By_ID($_GET['Recipe_ID']);
						Recipes::Display_Detail($Recipe, $_SESSION['Mem_ID']);
					}
					
				?>
				
				</div>
			</div>

	<div align="center">
		<?php include "includes/footer_menu.php"?>
	</div>
	<?php include "includes/footer_links.php"?>