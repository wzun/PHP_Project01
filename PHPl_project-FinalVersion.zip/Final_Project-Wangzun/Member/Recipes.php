<?php include "includes/header.php"?>

<body>
	<div id="page" align="center">
		<div id="content" style="width:800px">
			<?php include "includes/logo.php" ?>
			<?php include "includes/headerDiv.php" ?>
			<?php include "includes/menu.php"?>
		<div id="contenttext">
			
				<?php include_once "../classes/Message.php"?>
				<?php include_once "../classes/Carousel.php"?>
				<?php include_once "../classes/RecipesDB.php"?>
				<?php include_once "../classes/Category.php"?>
				<?php include_once "../classes/Rating.php"?>
				<?php include_once "../classes/Favorite.php"?>
				<?php include_once "../classes/MemberDB.php"?>
				<?php include_once "../classes/Sorting.php"?>
			
			<div class="bodytext" style="padding:12px;" align="justify">
				
				<center><h2 style="padding-top:20px;  color:indianred;">Welcome to choose our recipes !</h2></center>
				<br><br>
			<br/><br/>
    			<?php 
			 		$selected = 0;
					$recipes = Recipes::ReadRecipes();
					
					if(isset($_POST["v_sort"])){
						$selected = $_POST["v_sort"];							
						switch($selected){
							case 1: Sorting::ASortAscending($recipes,'Name');
									break;
							case 2: Sorting::ASortDescending($recipes,'Serving_Person');
									break;
						}
					}
				?>
					<form action ='#' method = "post">
					<h5><big>Sort by</big>
						<select name="v_sort" onchange = "this.form.submit();">
							<option value=0 <?php if($selected == 0)echo "selected"; ?>>Not sorted</option>
							<option value=1 <?php if($selected == 1)echo "selected"; ?>>By Recipes Name</option>
							<option value=2 <?php if($selected == 2)echo "selected"; ?>>By Serving High to Low</option>							
						</select></h5>
					</form>
					</br></br>
					<?php
						Recipes::Display_Favorite($recipes);					
					?>
			
				</div>
			</div>
		
	<div align="center">
		<?php include "includes/footer_menu.php"?>
	</div>
	<?php include "includes/footer_links.php"?>