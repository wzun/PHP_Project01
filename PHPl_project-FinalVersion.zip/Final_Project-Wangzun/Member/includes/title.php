<div style="padding:10px">
	<span class="titletext"><?php echo "Chapter ".$chapter." - Lab practice ".$lab; ?></span>
</div>