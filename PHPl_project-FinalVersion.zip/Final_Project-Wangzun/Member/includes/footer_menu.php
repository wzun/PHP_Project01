<div id="footer" class="smallgraytext">
<a href="Member.php"><i class="fa fa-home"></i> Home</a> | 
	<a href="Recipes.php"><i class="fa fa-star"></i> Recipes</a>| 
	<a href="Favorites.php"><i class="fa fa-heart"> </i> Favorite</a> | 
	<a href="Logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a>
</div>
