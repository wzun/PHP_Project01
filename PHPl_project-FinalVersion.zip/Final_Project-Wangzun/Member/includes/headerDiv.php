<div id="topheader">
	<div align="left" class="bodytext">
	<br />
	<h2><strong><?php echo "<font color =burlywood >";
				echo  "$LogoName";
				echo "</font>"; ?> </strong></h2><br />

	</div>
</div>