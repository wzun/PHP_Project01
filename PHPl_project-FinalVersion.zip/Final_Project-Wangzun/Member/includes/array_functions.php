<?php
$cars = array("Jeep"=> array("Year"=>2014, "Make"=>"Jeep" , "Model" =>"Grand-Cherokee", "Old_Price"=>48314 , "Price"=>38500 , "KM"=>70000, "Color"=>"Black" , "Image"=>"Jeep.jpg" ),
              "BMW"=>  array("Year"=>2016, "Make"=>"BMW" , "Model" =>"X5 M", "Old_Price"=>0 , "Price"=>126000 , "KM"=>90, "Color"=>"White" , "Image"=>"BMW.jpg" ),
			  "Acura"=>array("Year"=>2015, "Make"=>"Acura" , "Model" =>"MDX", "Old_Price"=>60876 , "Price"=>54399 , "KM"=>50000, "Color"=>"Black" , "Image"=>"Acura.jpg" ),
			  "Honda"=>array("Year"=>2016, "Make"=>"Honda" , "Model" =>"Pilot", "Old_Price"=>46320 , "Price"=>44999 , "KM"=>60, "Color"=>"Silver" , "Image"=>"Honda.jpg" ),
			  "Audi"=> array("Year"=>2015, "Make"=>"Audi" , "Model" =>"Q3", "Old_Price"=>0 , "Price"=>30988 , "KM"=>40000, "Color"=>"Black" , "Image"=>"Audi.jpg" )
			  );
			  

?>