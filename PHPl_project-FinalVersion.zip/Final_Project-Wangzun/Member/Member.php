<?php include "includes/header.php"?>

<body>
	<div id="page" align="center">
		<div id="content" style="width:800px">
			<?php include "includes/logo.php" ?>
			<?php include "includes/headerDiv.php" ?>
			<?php include "includes/menu.php"?>
		<div id="contenttext">
			
				<?php include_once "../classes/Message.php"?>
				<?php include_once "../classes/Carousel.php"?>
				<?php include_once "../classes/RecipesDB.php"?>
				<?php include_once "../classes/Category.php"?>
				<?php include_once "../classes/Rating.php"?>
				<?php include_once "../classes/Favorite.php"?>
				<?php include_once "../classes/MemberDB.php"?>
				<?php include_once "../classes/Sorting.php"?>
			
			<div class="bodytext" style="padding:12px;" align="justify">
				
				<center><h2 style="padding-top:20px;  color:indianred;">Welcome to choose our recipes !</h2></center>
				<br><br>
				
				<?php 
					
					Message::ShowMessage("Welcome Member");
					echo("<br><br>");

					$recipes_carousel = array("recipe1.jpg", "recipe2.jpg", "recipe3.jpg", "recipe4.jpg", "recipe5.jpg", "recipe6.jpg");
					Carousel::Show($recipes_carousel);
				?>
				
				</div><!-- End Bodytext -->
		</div><br>		
					
		<div class="container-fluid padding-enabled bcolor-grey" style="float: right">
		<h2 class="text-green text-center">Contact US</h2>
		<br><br>
		<div class="row">
			<div class="col-sm-3">
				<p><strong>Contact information:</strong></p>
				<p><span class="glyphicon glyphicon-map-marker text-green"></span> Montreal, Canada</p>
				<p><span class="glyphicon glyphicon-phone text-green"></span> (888)888-8888</p>
				<p><span class="glyphicon glyphicon-envelope text-green"></span> RECIPES@gmail.com</p>
			</div>
			<div class="col-sm-9">
				<div class="row">
					<div class="col-sm-6 form-group">
						<input class="form-control" name="name" placeholder="Enter your name:" type="text" required="required">
					</div>
					<div class="col-sm-6 form-group">
						<input class="form-control" name="email" placeholder="Enter your email:" type="email" required="required">
					</div>
				</div>
				<textarea name="comment" rows="4" class="form-control" placeholder="Enter your comment:"></textarea>
				<br>
				<div class="row">
					<div class="col-sm-12 form-group">
						<button type="submit" class="btn btn-success">Send</button>
					</div>
				</div>
			</div>
		</div>
	</div>		

	<div align="center">
		<?php include "includes/footer_menu.php"?>
	</div>
				</div>
	</div>	
	<?php include "includes/footer_links.php"?>