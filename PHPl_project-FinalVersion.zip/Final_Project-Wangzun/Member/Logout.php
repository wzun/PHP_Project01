<?php 
	ob_start(); 
		header('Location: ../HomePage.php');

		if(!isset($_SESSION)){
			session_start();
		}
		if(!empty($_SESSION['Username'])){
			$_SESSION['Username'] = NULL;
		}
		if(!empty($_SESSION['Mem_ID'])){
			$_SESSION['Mem_ID'] = NULL;
		}
?>