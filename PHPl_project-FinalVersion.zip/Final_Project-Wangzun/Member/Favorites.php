<?php include "includes/header.php"?>

<body>
	<div id="page" align="center">
		<div id="content" style="width:800px">
			<?php include "includes/logo.php" ?>
			<?php include "includes/headerDiv.php" ?>
			<?php include "includes/menu.php"?>
		<div id="contenttext">
			
				<?php include_once "../classes/Message.php"?>
				<?php include_once "../classes/Carousel.php"?>
				<?php include_once "../classes/RecipesDB.php"?>
				<?php include_once "../classes/Category.php"?>
				<?php include_once "../classes/Rating.php"?>
				<?php include_once "../classes/Favorite.php"?>
				<?php include_once "../classes/MemberDB.php"?>
				<?php include_once "../classes/Sorting.php"?>
			
			<div class="bodytext" style="padding:12px;" align="justify">
				
				<center><h2 style="padding-top:20px;  color:indianred;">Welcome to choose our recipes !</h2></center>
				<br><br>
				
				<?php 
					if(!isset($_SESSION)){
						session_start();
					}
										
					$Mem_ID = $_SESSION['Mem_ID'];
					
					if(isset($_POST['Delete'])){
						$Recipe_ID = $_POST['Recipe_ID'];
						Favorite::Delete_Favorite($Mem_ID, $Recipe_ID);
					}
														
					$array = Recipes::Get_Favorite_Recipes($Mem_ID);
					Recipes::Display_Favorite($array, TRUE);				
					
				?>
				
				</div>
			</div>
			
			
	<div align="center">
		<?php include "includes/footer_menu.php"?>
	</div>
	<?php include "includes/footer_links.php"?>