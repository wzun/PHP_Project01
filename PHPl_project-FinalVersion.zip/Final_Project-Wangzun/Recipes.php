<?php include "includes/header.php"?>

<body>
	<div id="page" align="center">
		<div id="content" style="width:800px">
			<?php include "includes/logo.php" ?>
			<?php include "includes/headerDiv.php" ?>
			<?php include "includes/menu.php"?>
		<div id="contenttext">
			
			<div class="bodytext" style="padding:12px;" align="justify">
				
				<center><h2 style="padding-top:20px;  color:darkgoldenrod;">Welcome to choose our recipes !</h2></center>
				
				<?php include_once "classes/Message.php"?>
				<?php include_once "classes/Carousel.php"?>
				<?php include_once "classes/RecipesDB.php"?>
				<?php include_once "classes/Category.php"?>
				<?php include_once "classes/Rating.php"?>
				<?php include_once "classes/Favorite.php"?>
				<?php include_once "classes/MemberDB.php"?>
				<?php include_once "classes/Sorting.php"?>

				<?php
						$Category_ID = 0;
						$Checked  = 0;
						$Keywords = "";					
					?>
					<script>
							function updateSeachBy(){
							document.getElementById("searchBy").checked = true;
							}
					</script>		
  		<br><br>
         
           <form action="#" method="post" >
              
			   <!----------0------------>
			  <h5><input type="radio" name="search" id = "searchALL" value="0" <?php if($Checked == 0){echo "checked"; } ?>> Display all recipes</h5><br>
			  <br>
			  
			   <!----------1------------> 
			  <h5><input type="radio" name="search" id = "searchByCategory" value="1" <?php if($Checked == 1){echo "checked"; } ?>> Search Recipes By Category:
			  
				<select name='RecipesCategory' style="font-weight:bold;font-size:13pt" onChange="updateSeachBy()">
				<option value = '0'>None </option>
				<?php 
				    for($i=1; $i<=6; $i++){
				       
					   $category = Category::Get_Category_Name($i);
					   echo "<option value=\"$i\" ";
					
                        if($category == $i){echo "selected"; }
						      echo ">$category</option>";
					    }
				?>
				</select></h5>
				<br/><br/>
			   
			    <!----------2------------> 
			  <h5><input type="radio" name="search" id = "searchByMealType" value="2" <?php if($Checked == 2){echo "checked"; } ?>> Search Recipes By meal type:
			  
				<select name='RecipesMealType' style="font-weight:bold;font-size:13pt" onChange="updateSeachBy()">
				<option value = '0'>None </option>
				<?php 			
				    
					for($i=1; $i<=6; $i++){
				       $MealType = Category::Get_MealType_Name($i);
					   echo "<option value=\"$i\" ";
					
                        if($MealType == $i){echo "selected"; }
						      echo ">$MealType</option>";
					    }
				?>
				</select></h5>
				<br/><br/>
				
				<h5><input type="submit" name="submit" value="Search Recipes"><h5>
                				            
          </form>           
           <?php 
			
				//Data Processing and Display
				if(isset($_POST["search"])){
					$checked  = $_POST["search"];
					
					switch($checked){
					Case 0:
						$recipes = Recipes::ReadRecipes();
						Recipes::Display_Visitor($recipes);
						break;
					Case 1:
						$query = $_POST['RecipesCategory'];

						$recipes = Recipes::Search_By_CAT_ID($query);
						Recipes::Display_Visitor($recipes);
						break;
					Case 2:
						$query = $_POST['RecipesMealType'];
						
						$recipes = Recipes::Search_By_MealType($query);
						Recipes::Display_Visitor($recipes);						
					}
				}
       ?>		  
         						
			</div>
		</div>

	<div align="center">
		<?php include "includes/footer_menu.php"?>
	</div>
	<?php include "includes/footer_links.php"?>