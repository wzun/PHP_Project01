-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: July 7, 2019 at 12:00 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `recipes_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `recipes`
--

CREATE TABLE `recipes` (
  `Recipe_ID` int(11) NOT NULL,
  `Name` varchar(32) NOT NULL,  
  `Preparation_Time` varchar(32) NOT NULL,
  `Cooking_Time` varchar(32) NOT NULL,
  `Serving_Person` int(11) NOT NULL, 
  `MealType_ID` int(11) NOT NULL,
  `MealType_Name` varchar(32) NOT NULL,
  `Preparation` varchar(255) NOT NULL,
  `Image` varchar(255) NOT NULL,
  `Rating` float(10),
  `Recipe_Date` DATE,
  `Ing_ID` int(11) NOT NULL  
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recipes`
--

INSERT INTO `recipes` (`Recipe_ID`, `Name`, `Preparation_Time`, `Cooking_Time`,
`Serving_Person`, `MealType_ID`, `MealType_Name`,`Preparation`, `Image`, `Rating`, `Recipe_Date`, `Ing_ID`) VALUES
(1, 'Barbecued Pork Shoulder', '5 MIN', '2 H 15 MIN', 6, 1, 'Main Dishes', 'Preheat the grill,setting
 the burners to high. Oil the grate.  
 meat is cooked and tender, maintaining a grill temperature of 400°F (200°C). Remove from the heat.
 Remove the bone and the skin. Delicious served with baked sweet potatoes with onion (see recipe), 
 honey bourbon sauce or quick barbecue sauce (see recipes).', 
 'Barbecued Pork Shoulder.jpg', null, '2019-07-01', 1),
(2, 'Quinoa Veggie Burgers', '25 MIN', '35 MIN', 2, 2,'Quick Dishes', 'In a bowl, combine all the 
ingredients. Season with salt and pepper. Refrigerate until ready to serve.Veggie Burger In a 
saucepan of salted boiling water, cook the quinoa for about 15 minutes, or until it tender.  
shape into 4 patties of about 1/2 cup each. In the same non-stick skillet over medium-high heat, 
cook the patties for 2 to 3 minutes on each side in the remaining oil (3 tbsp).', 
 'Quinoa Veggie Burgers.jpg', null, '2019-07-02', 2),
(3, 'Beef Stew with Green Vegetables', '22 MIN', '3 H 25 MIN', 4, 3, 'Enter Dishes', 'Cover and bake 
for 2 hours or until the meat is fork tender. Remove from the oven.
In a small bowl, whisk the cornstarch and water until smooth.
Place the skillet over medium heat. Drizzle in the cornstarch mixture and bring to a boil, stirring 
constantly. Adjust the seasoning.', 
 'Beef Stew.jpg', null, '2019-07-03', 3),
(4, 'Chocolate Croissants', '26 MIN', '1 H 25 MIN', 3, 4, 'Breakfast Dishes', 'With the rack in the 
middle position, preheat the oven to 350°F (180°C).
With a pastry brush, gently brush the dough rolls with the beaten egg, covering them completely.
Bake for 25 minutes or until golden. Let cool on a wire rack.', 
 'Chocolate Croissants.jpg', null, '2019-07-04', 4),
(5, 'Creamy Scrambled Eggs', '15 MIN', '55 MIN', 2, 4, 'Breakfast Dishes', 'In a bowl, whisk the 
eggs, milk and cream until smooth. Season with salt and pepper.
In a large non-stick skillet, melt the butter. Add the egg mixture. 
Cook over medium-low heat, stirring constantly with a wooden spoon, 
spatula or whisk (see note) for 23 to 25 minutes or until the eggs are just cooked. Remove from 
the heat. Adjust the seasoning.', 
 'Creamy Scrambled Eggs.jpg', null, '2019-07-05', 5),
(6, 'Cranberry Crusted Salmon', '15 MIN', '1 H 55 MIN', 6, 1, 'Main Dishes', 'With the rack in the 
middle position, preheat the oven to 400°F (200°C). Line a baking sheet with parchment paper.
Place the salmon on the prepared sheet, skin side down. Season with salt and pepper.
In a bowl, combine the cranberries, maple syrup and mustard. Spread over the salmon. Bake for 
15 minutes or until the salmon is cooked medium rare.
Sprinkle with chervil. Serve hot or at room temperature.', 
 'Cranberry Crusted Salmon.jpg', null, '2019-07-06', 6),
(7, 'Lemon Chiffon Cake', '50 MIN', '6 H 55 MIN', 8, 5, 'Dessert Dishes', 'With the rack in the 
middle position, preheat the oven to 325°F (165°C). Line the bottom of two 8-inch (20 cm) 
springform pans with parchment paper. Do not butter the pans.
In a bowl, combine the flour and baking powder. Set aside.
In a large bowl, whisk together the egg yolks with ¾ cup (160 g) of the sugar, the oil, lemon 
zest and juice, and salt. Set aside.
In a third bowl, beat the egg whites with an electric mixer until soft peaks form. Gradually 
add the remaining sugar, beating until stiff peaks form.', 
 'Lemon Chiffon Cake.jpg', null, '2019-07-06', 7),
(8, 'Pressure Cooker Pea Soup', '40 MIN', '1 H 45 MIN', 4, 6,'Soup Dishes', 'Preheat the pressure 
cooker on the Sauté function for 2 minutes. Brown the pork in the oil. Add the onion, carrots and 
celery. Cook for 5 minutes. Add the split peas, broth and bay leaf. Season with pepper.
Cover and select the Bean function. Set the machine to cook for 20 minutes.
Let the pressure release and remove the lid. Discard the bay leaf and add the ham, if using. Adjust 
the seasoning. Add more broth for a more liquid soup.', 
 'Pressure Cooker Pea Soup.jpg', null, '2019-07-04', 8),
(9, 'Shrimp with Mustard Sauce', '20 MIN', '1 H 05 MIN', 4, 1, 'Main Dishes', 'In a bowl, whisk together 
the cornstarch and water. Stir in the mustard and set aside.
In a large skillet over high heat, cook the shrimp in the oil until just pink. Season with salt and 
pepper. Set aside on a plate.
In the same skillet still over high heat, soften the onion, chili pepper and garlic. Return the shrimp 
to the skillet and deglaze with the wine. Drizzle in the mustard mixture and bring to a boil, stirring 
constantly. Add the lemon juice and adjust the seasoning.', 
 'Shrimp with Mustard Sauce.jpg', null, '2019-07-02', 9),
(10, 'Lentil Cassoulet', '50 MIN', '2 H 05 MIN', 6, 1, 'Main Dishes', 'In a bowl, soak the mushrooms in the 
warmed wine for 20 minutes. Drain. Set aside the mushrooms and wine separately.
Meanwhile, in a large pot, brown the duck legs, skin side down, in the oil. Remove and set aside on a 
plate. In the same pan, brown the bacon and onion in the rendered duck fat. Add the mushrooms, celery 
and sausage and cook for 2 minutes over high heat. Add the lentils and mix thoroughly.', 
 'Lentil Cassoulet.jpg', null, '2019-07-01', 10);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `Cat_ID` int(11) NOT NULL,
  `Cat_Name` varchar(255) NOT NULL,
  `Image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`Cat_ID`, `Cat_Name`, `Image`) VALUES
(1, 'Weekday Recipes', 'Weekday Recipes.jpg'),
(2, 'Comfort food', 'Comfort food,jpg'),
(3, 'Healthy', 'Healthy.jpg'),
(4, 'Breakfast', 'Breakfast.jpg'),
(5, 'Canada Day', 'Canada Day.jpg'),
(6, 'The Best', 'The Best.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `recipes_categories`
--

CREATE TABLE `recipes_categories` (
  `Recipe_ID` int(11) NOT NULL,
  `Cat_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recipes_categories`
--

INSERT INTO `recipes_categories` (`Recipe_ID`, `Cat_ID`) VALUES
(1, 1),(1, 2),(1, 5),
(2, 2),(2, 3),(2, 4),
(3, 1),(3, 2),
(4, 3),(4, 4),
(5, 2),(5, 3),(5, 4),
(6, 1),(6, 5),(6, 6),
(7, 5),(7, 6),
(8, 1),(8, 2),(8, 3),(8, 6),
(9, 1),(9, 2),(9, 5),(9, 6),
(10, 1),(10, 3),(10, 5),(10, 6);

-- --------------------------------------------------------

--
-- Table structure for table `meal_type`
--

CREATE TABLE `meal_type` (
  `MealType_ID` int(11) NOT NULL,
  `MealType_Name` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meal_type`
--

INSERT INTO `meal_type` (`MealType_ID`, `MealType_Name`) VALUES
(1, 'Main Dishes'),
(2, 'Quick Dishes'),
(3, 'Enter Dishes'),
(4, 'Breakfast Dishes'),
(5, 'Dessert Dishes'),
(6, 'Soup Dishes');

-- --------------------------------------------------------

--
-- Table structure for table `ingredient`
--

CREATE TABLE `ingredient` (
  `Ing_ID` int(11) NOT NULL,
  `Ing_List` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ingredient`
--

INSERT INTO `ingredient` (`Ing_ID`, `Ing_List`) VALUES
(1, '1 4-lb pork shoulder (1.8 kg), with the skin; 2 tbsp basic dry rub (see recipe)'),
(2, '1. 6 tbsp (90 ml) tahini; 2. 1/4 cup (60 ml) water ;3. 2 tbsp (30 ml) mayonnaise
4. 1 tbsp (15 ml) lemon juice 5. Salt and pepper'),
(3, '1. 2 eggs ;2. 3 tablespoons (45 ml) unbleached all-purpose flour; 3. 1 teaspoon (5 ml) soy sauce;
4. 1 green onion, finely chopped; 5. 1 cup (250 ml) thinly sliced green cabbage;
6. ½ small onion, finely chopped'),
(4, '1. 6 raw medium shrimp, peeled and cut into 1/2-inch (1-cm) chunks;
2. 1/2 teaspoon (2.5 ml) dried seaweed powder or finely chopped nori;
3. Japanese or plain mayonnaise (see note), to taste;
4. Tonkatsu sauce, to taste (see recipe)'),
(5, '1. 2-lb (900 g) beef rib steak 2 inches (5 cm) thick with a bone about 12 inches (30 cm) long (tomahawk);
2. 1 1/2 tsp basic dry rub (see recipe);
3. 1 tbsp (15 ml) olive oil;
4. 1 tbsp salted butter'),
(6, '1. 1 lb(450 g) whole white mushrooms;
2. 2 tbsp (30 ml) olive oil;
3. 10 eggs;
4. 1 tbsp butter'),
(7, '1. 1 lb(450 g) whole white mushrooms;
2. 2 tbsp (30 ml) olive oil;
3. 10 eggs;
4. 1 tbsp butter'),
(8, '1. 1 garlic clove, chopped;
2. 1 tbsp (15 ml) olive oil;
3. 1/4 cup (10 g) chopped parsley;
4. 1 tbsp chopped chives;
5. 4 slices dried baguette, toasted and crumbled;
6. 3 tbsp (15 g) freshly grated Parmesan cheese'),
(9, '1. 1.5 lb(450 g) whole white mushrooms;
2. 3 tbsp (30 ml) olive oil;
3. 5 eggs;
4. 2 tbsp butter'),
(10, '1. 1 tsp garlic powder;
2. 1 tsp red pepper flakes;
3. 1 tsp dried oregano;
4. ½ tsp ground cumin;
5. ½ tsp celery salt;
6. ½ tsp dried thyme;
7. ½ tsp salt');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `Mem_ID` int(11) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Salt` varchar(255) 
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `members`
--

-- --------------------------------------------------------

CREATE TABLE `comment` (
  `comment_Id` int(11) NOT NULL,
  `comment_recipe` int(11) NOT NULL,
  `comment_sender` varchar(50) NOT NULL,
  `comment_txt` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `comment`
--

INSERT INTO `comment` (`comment_Id`, `comment_recipe`, `comment_sender`, `comment_txt`) VALUES
(1, 2, '1', 'Those brochettes are so good, I\'ve done them for my family and I only get good feedback from them. Thanks !!!'),
(2, 5, '1', 'A little bit long to do but worth it ! Thank you '),
(3, 3, '2', 'good'),
(4, 8, '1', 'Yeah really good !'),
(5, 5, '2', 'where are the banana pancakes ?'),
(6, 6, '2', 'Finaly !!!! yewww'),
(7, 1, '2', 'hello');


-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `Recipe_ID` int(11) NOT NULL,
  `Mem_ID` int(11) NOT NULL,
  `Rating` varchar(255)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `favorites`
--

CREATE TABLE `favorites` (
  `Recipe_ID` int(11) NOT NULL,
  `Mem_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


--
-- Indexes for dumped tables
--

-- ------------------------------------------------------------------------------------------
--
-- Indexes for table `recipes`
--
ALTER TABLE `recipes`
  ADD PRIMARY KEY (`Recipe_ID`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`Cat_ID`);
  
--
-- Indexes for table `recipes_categories`
--
ALTER TABLE `recipes_categories`
  ADD PRIMARY KEY (`Recipe_ID`, `Cat_ID`);

--
-- Indexes for table `ingredient`
--
ALTER TABLE `ingredient`
  ADD PRIMARY KEY (`Ing_ID`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`comment_Id`);
 
--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`Mem_ID`),  
  ADD UNIQUE KEY `Username` (`Username`),
  ADD UNIQUE KEY `Email` (`Email`);
  
--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`Recipe_ID`, `Mem_ID`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`Recipe_ID`, `Mem_ID`);


--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `recipes`
--
ALTER TABLE `recipes`
  MODIFY `Recipe_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `Cat_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
  
--
-- AUTO_INCREMENT for table `ingredient`
--
ALTER TABLE `ingredient`
  MODIFY `Ing_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
  
  
--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `Mem_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `comment_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;


--
-- Constraints for dumped tables
--

--
-- Constraints for table `recipes`
--
ALTER TABLE `recipes`
  ADD CONSTRAINT `recipes_FK` FOREIGN KEY (`Ing_ID`) REFERENCES `ingredient` (`Ing_ID`);

--
-- Constraints for table `recipes_categories`
--
ALTER TABLE `recipes_categories`
  ADD CONSTRAINT `recipes_categories_FK1` FOREIGN KEY (`Recipe_ID`) REFERENCES `recipes` (`Recipe_ID`);
ALTER TABLE `recipes_categories`
  ADD CONSTRAINT `recipes_categories_FK2` FOREIGN KEY (`Cat_ID`) REFERENCES `categories` (`Cat_ID`);

--
-- Constraints for table `ratings`
--
ALTER TABLE `ratings`
  ADD CONSTRAINT `ratings_FK1` FOREIGN KEY (`Recipe_ID`) REFERENCES `recipes` (`Recipe_ID`);
ALTER TABLE `ratings`
  ADD CONSTRAINT `ratings_FK2` FOREIGN KEY (`Mem_ID`) REFERENCES `members` (`Mem_ID`);


--
-- Constraints for table `favorites`
--
ALTER TABLE `favorites`
  ADD CONSTRAINT `favorites_FK1` FOREIGN KEY (`Recipe_ID`) REFERENCES `recipes` (`Recipe_ID`);
ALTER TABLE `favorites`
  ADD CONSTRAINT `favorites_FK2` FOREIGN KEY (`Mem_ID`) REFERENCES `members` (`Mem_ID`);



COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
